local MobTracker = include("mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()
local character_info = {name = "Spikey", height=54}

local fireball_texture = Engine.load_texture(_modpath.."fireball.png")
local fireball_sfx = Engine.load_audio(_modpath.."sfx.ogg")

local teleport_animation_path = _modpath .. "teleport.animation"
local teleport_texture_path = _modpath .. "teleport.png"
local teleport_texture = Engine.load_texture(teleport_texture_path)
local explosion_texture = Engine.load_texture(_modpath.."spell_explosion.png")

local debug = false
local function debug_print(text)
    if debug then
        print("[spikey] " .. text)
    end
end

function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

function package_init(self)
    debug_print("package_init called")
    -- Required function, main package information

    -- Load character resources
    self.texture = Engine.load_texture(_modpath .. "battle.greyscaled.png")
    self.animation = self:get_animation()
    self.animation:load(_modpath .. "battle.animation")

    -- Load extra resources

    -- Set up character meta
	self:set_texture(self.texture, true)
    self:set_height(character_info.height)
    self:share_tile(false)
    self:set_explosion_behavior(1, 1, false)
    self:set_offset(0, 0)
	self:set_name(character_info.name)
	self:set_element(Element.Fire)
	if self:get_rank() == Rank.V2 then
		self:set_health(150)
		self:set_palette(Engine.load_texture(_modpath.."battle_v2.palette.png"))
		self.move_before_attack = 6
		self.current_moves = 6
	elseif self:get_rank() == Rank.V3 then
		self:set_health(280)
		self:set_palette(Engine.load_texture(_modpath.."battle_v3.palette.png"))
		self.move_before_attack = 5
		self.current_moves = 5
	else
		self:set_health(60)
		self:set_palette(Engine.load_texture(_modpath.."battle_v1.palette.png"))
		self.move_before_attack = 7
		self.current_moves = 7
    end

    --defense rules
    self.defense = Battle.DefenseVirusBody.new()
    print("defense was created")
    self:add_defense_rule(self.defense)

    -- Initial state
    self.animation:set_state("IDLE")
    self.animation:set_playback(Playback.Loop)
    self.frames_between_actions = 40
    self.cascade_frame_index = 5 --lower = faster fireballs
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false

    self.update_func = function(self, dt)
		take_turn(self)
        if self.current_moves <= 0 then
            initiate_attack(self)
        end
    end

    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        local field = self:get_field()
        local mob_sort_func = function(a,b)
            local met_a_tile = field:get_entity(a):get_current_tile()
            local met_b_tile = field:get_entity(b):get_current_tile()
            local var_a = (met_a_tile:x()*3)+met_a_tile:y()
            local var_b = (met_b_tile:x()*3)+met_b_tile:y()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func,true)--reverse sort direction
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.on_spawn_func = function(self, spawn_tile)
        debug_print("on_spawn_func called")
        add_enemy_to_tracking(self)
    end
    self.can_move_to_func = function(tile)
        debug_print("can_move_to_func called")
        return is_tile_free_for_movement(tile,self)
    end
    self.delete_func = function(self) 
        debug_print("delete_func called")
        remove_enemy_from_tracking(self)
    end
end

function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        debug_print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

function take_turn(self)
    local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end
	
	local moved_randomly = move_at_random(self)

	if moved_randomly then
		self.ai_wait = self.frames_between_actions
		self.ai_taken_turn = false
		self.current_moves = self.current_moves - 1
		return
	end
end

function initiate_attack(self)
	local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end
	
	local moved = move_towards_character(self)
	
	if not moved then
		return
	end
	
	self.current_moves = self.move_before_attack
	
	local fireball_action = action_fireball(self)
    local next_action = fireball_action
    next_action.action_end_func = function()
        local facing = self:get_facing()
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        advance_a_turn_by_facing(facing)
    end
    self:card_action_event(next_action, ActionOrder.Voluntary)
end

function move_at_random(self)
	local current_tile = self:get_tile()
	local field = self:get_field()
	local target_tile_x = math.floor(math.random(6))
	local target_tile_y = math.floor(math.random(3))
	local target_tile = nil
	local dummy_tile = nil
	local is_occupied = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
	while target_tile == nil do
		local dummy_tile = field:tile_at(target_tile_x, target_tile_y)
		if not dummy_tile then
			target_tile_x = math.floor(math.random(6))
			target_tile_y = math.floor(math.random(3))
		else
			if not dummy_tile:is_walkable() or dummy_tile:is_edge() or dummy_tile:is_reserved({self:get_id()}) or #dummy_tile:find_entities(is_occupied) > 0 then
				target_tile_x = math.floor(math.random(6))
				target_tile_y = math.floor(math.random(3))
			else
				target_tile = dummy_tile
			end
		end
	end
	moved = self:teleport(target_tile, ActionOrder.Immediate)
	if moved then
		spawn_visual_artifact(target_tile,self,teleport_texture,teleport_animation_path,"SMALL_TELEPORT_FROM",0,0)
	end
	return moved
end

function move_towards_character(self)
    local target_character = find_target(self)
    local target_character_tile = target_character:get_current_tile()
    local tile = self:get_current_tile()
    local moved = false
    local target_movement_tile = nil
	local is_occupied = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
	for i = 1, 6, 1 do
		if target_movement_tile ~= nil then
			break		
		else
			local check_tile = target_character:get_tile(target_character:get_facing(), i)
			if check_tile and check_tile:is_walkable() and self:is_team(check_tile:get_team()) and #check_tile:find_entities(is_occupied) == 0 then
				target_movement_tile = check_tile
			end
		end
	end
    if target_movement_tile then
        moved = self:teleport(target_movement_tile, ActionOrder.Immediate)
        if moved then
            spawn_visual_artifact(tile,self,teleport_texture,teleport_animation_path,"SMALL_TELEPORT_FROM",0,0)
        end
    end
    return moved
end

function action_fireball(character)
	print("started fireball action")
    local action_name = "fireball"
    local facing = character:get_facing()
    debug_print('action ' .. action_name)
	local damage = 30
	if character:get_rank() == Rank.V2 then
		damage = 90
	elseif character:get_rank() == Rank.V3 then
		damage = 150
	end
    local action = Battle.CardAction.new(character, "ATTACK")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2,function ()
            character:toggle_counter(true)
        end)
		self:add_anim_action(4,function()
            local tile = character:get_tile(facing,1)
            spawn_fireball(character, tile, facing, damage, fireball_texture, fireball_sfx, character.cascade_frame_index)
        end)
        self:add_anim_action(6,function ()
            character:toggle_counter(false)
        end)
	end
	character.ai_taken_turn = true
    return action
end

function is_tile_free_for_movement(tile,character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if tile:get_team() ~= character:get_team() then return false end
    if not tile:is_walkable() then return false end
    local occupants = tile:find_characters(function(other_character)
        return true
    end)
    if #occupants > 0 then 
        return false
    end
    return true
end

function spawn_visual_artifact(tile,character,texture,animation_path,animation_state,position_x,position_y)
    local field = character:get_field()
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture,true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x,position_y)
    field:spawn(visual_artifact, tile:x(), tile:y())
end

function spawn_fireball(owner, tile, direction, damage, fireball_texture, fireball_sfx, cascade_frame_index)
	print("in spawn fireball")
    local owner_id = owner:get_context()
    local team = owner:get_team()
    local field = owner:get_field()
    Engine.play_audio(fireball_sfx, AudioPriority.Low)
	local spell = Battle.Spell.new(team)
	spell:set_texture(fireball_texture)
	spell:set_facing(direction)
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			damage, 
			Hit.Impact | Hit.Flash, 
			Element.Fire, 
			owner_id, 
			Drag.None
		)
	)
	local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil and not ent:is_team(spell:get_team()) or Battle.Character.from(ent) ~= nil and not ent:is_team(spell:get_team())
	end
	local sprite = spell:sprite()
	sprite:set_layer(-1)
	local animation = spell:get_animation()
	animation:load(_modpath .. "fireball.animation")
	animation:set_state("DEFAULT")
	animation:refresh(sprite)
	
	spell.has_hit = false
	
	spell.update_func = function(self, dt)
		spell:get_current_tile():attack_entities(spell)
		if self:get_current_tile():is_edge() and self.slide_started then 
			self:delete()
		end 
		
		local dest = self:get_tile(spell:get_facing(), 1)
		local ref = self
		if not self.has_hit then
			self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, 
				function()
					ref.slide_started = true 
				end
			)
		end
	end
	spell.collision_func = function(self, other)
		self.has_hit = true
		local fx1 = Battle.Artifact.new()
		fx1:set_texture(explosion_texture, true)
		local fx1_anim = fx1:get_animation()
		fx1_anim:load(_modpath.."spell_explosion.animation")
		fx1_anim:set_state("Default")
		fx1_anim:refresh(fx1:sprite())
		fx1:sprite():set_layer(-2)
		fx1_anim:on_complete(function()
			fx1:erase()
		end)
		field:spawn(fx1, self:get_tile())
		local tile = spell:get_tile():get_tile(spell:get_facing(), 1)
		if tile and not tile:is_edge() then
			local hitbox = Battle.Hitbox.new(spell:get_team())
			hitbox:set_hit_props(spell:copy_hit_props())
			local fx = Battle.Artifact.new()
			fx:set_texture(explosion_texture, true)
			local fx_anim = fx:get_animation()
			fx_anim:load(_modpath.."spell_explosion.animation")
			fx_anim:set_state("Default")
			fx_anim:refresh(fx1:sprite())
			fx:sprite():set_layer(-2)
			fx_anim:on_complete(function()
				fx:erase()
			end)
			field:spawn(fx, tile)
			field:spawn(hitbox, tile)
		end
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	field:spawn(spell, tile)
end
